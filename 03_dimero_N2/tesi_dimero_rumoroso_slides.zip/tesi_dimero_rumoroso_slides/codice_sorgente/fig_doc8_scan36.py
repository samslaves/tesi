"""Figura aggiuntiva del documento 8 -- scan completo sulle 36 combinazioni
C_ij^{alpha,beta}(t=2) sotto rumore di riferimento, per verificare che il
correlatore di riferimento (C_11^yz) sia un caso rappresentativo e non un
estremo della distribuzione. Script separato da fig_doc8.py (nome distinto)
perche' il contenuto -- uno scan sistematico, non una singola curva -- e'
concettualmente diverso, non solo un aggiornamento dello stesso grafico."""
import json
import os
import numpy as np
import matplotlib.pyplot as plt
from stile import *
from correlatori_rumorosi_dimero import correlator_rumoroso, J_DEFAULT, b_DEFAULT, D_DEFAULT
from noise_model_dimero import build_noise_model

os.makedirs("figure", exist_ok=True)

data = np.load("ground_state_test2.npz")
vqe_params = data["vqe_params"]
nm_ref, params_ref = build_noise_model()
p_ro = params_ref["p_readout"]

N_grid = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20, 25, 30, 40]
t = 2.0

combos = [(i, alpha, j, beta)
          for i in [1, 2] for alpha in ["x", "y", "z"]
          for j in [1, 2] for beta in ["x", "y", "z"]]

righe = []
for (i, alpha, j, beta) in combos:
    vals0, valsN = [], []
    for N in N_grid:
        c0 = correlator_rumoroso(i, alpha, j, beta, t, N, J_DEFAULT, b_DEFAULT, D_DEFAULT,
                                  vqe_params, noise_model=None, p_readout=0.0)
        cN = correlator_rumoroso(i, alpha, j, beta, t, N, J_DEFAULT, b_DEFAULT, D_DEFAULT,
                                  vqe_params, noise_model=nm_ref, p_readout=p_ro)
        vals0.append(abs(c0))
        valsN.append(abs(cN))
    vals0, valsN = np.array(vals0), np.array(valsN)
    idx0, idxN = int(np.argmax(vals0)), int(np.argmax(valsN))
    righe.append({"i": i, "alpha": alpha, "j": j, "beta": beta,
                   "Nstar_0": N_grid[idx0], "Cstar_0": float(vals0[idx0]),
                   "Nstar_N": N_grid[idxN], "Cstar_N": float(valsN[idxN]),
                   "vals_0": vals0.tolist(), "vals_N": valsN.tolist()})

with open("scan36_rumore_risultati.json", "w") as f:
    json.dump({"N_grid": N_grid, "righe": righe}, f, indent=1)

# ------------------------------------------------------------- figura
fig, (a1, a2) = plt.subplots(1, 2, figsize=(11.5, 4.6))

Nstars = [r["Nstar_N"] for r in righe]
vals, counts = np.unique(Nstars, return_counts=True)
a1.bar(vals, counts, color=C_BLU, width=0.6)
a1.set_xlabel(r"$N^*$")
a1.set_ylabel("numero di combinazioni (su 36)")
a1.set_title(r"Distribuzione di $N^*$ sulle 36 combinazioni")
a1.set_xticks(range(1, 6))

for r in righe:
    a2.plot(N_grid, r["vals_N"], color="0.75", lw=0.8, zorder=1)
highlight = {(2, "x", 1, "x"): (C_ROSSO, r"$C_{21}^{xx}$ ($N^*{=}5$, più fragile)"),
             (1, "y", 1, "z"): (C_BLU, r"$C_{11}^{yz}$ ($N^*{=}2$, riferimento)"),
             (2, "z", 1, "z"): (C_VERDE, r"$C_{21}^{zz}$ ($N^*{=}1$, più ampio)")}
for r in righe:
    key = (r["i"], r["alpha"], r["j"], r["beta"])
    if key in highlight:
        col, lab = highlight[key]
        a2.plot(N_grid, r["vals_N"], color=col, lw=2.2, label=lab, zorder=3)
a2.set_xlabel(r"$N$")
a2.set_ylabel(r"$|C(N)|$")
a2.set_title("Tutte le 36 curve, rumore di riferimento")
a2.legend(fontsize=8, loc="upper right")

salva(fig, "fig_scan36_rumore_dimero")

n_ok = sum(1 for r in righe if r["Cstar_N"] > 0)
print(f"N* min={min(Nstars)} max={max(Nstars)} media={np.mean(Nstars):.2f}")
Cstars = [r["Cstar_N"] for r in righe]
print(f"|C(N*)| min={min(Cstars):.4f} max={max(Cstars):.4f}")
