"""
Genera fig_blocchi_dm_trimero_anello.pdf: struttura a blocchi di H (in
valore assoluto, soglia 1e-8) nella base di Kambe, per le due opzioni del
termine DM (Opzione A simmetrica, Opzione B adottata).

Punto di lavoro: J=1, J'=0.4, b/J=2.372 (vicino all'incrocio), D/J=0.15
-- stessi valori usati per il gap minimo vero riportato nel testo
(analisi_dm_trimero_anello.tex).

Verifica di coerenza prima di salvare: max|[P12,H_DM]| per le due opzioni
deve dare 0 (Opzione A) e 0.42 (Opzione B), come gia' noto da
trimer_ring_exact.py::_self_test_dm. Se la struttura a blocchi attesa
(2x2 isolato + 6x6 misto per A; 8x8 pieno per B) non emerge, lo script
si ferma con un errore invece di produrre comunque la figura.
"""
import numpy as np
from matplotlib.colors import ListedColormap
from trimer_ring_exact import trimer_hamiltonian_dm, kambe_states
from stile import plt, C_VIOLA

J, JP, B_WORK, D_WORK = 1.0, 0.4, 2.372, 0.15
SOGLIA = 1e-8

# ordine degli 8 stati sugli assi (identico su righe e colonne)
ORDINE = [("C", 0.5), ("C", -0.5),
          ("A", 1.5), ("A", 0.5), ("A", -0.5), ("A", -1.5),
          ("B", 0.5), ("B", -0.5)]


def _etichetta_stato(blocco, M):
    """'C, M=+½' / 'A, M=+3/2' ecc. -- stessa notazione (blocco, M) usata
    per identificare gli stati di Kambe nel resto del documento."""
    if M == 1.5:
        m_str = "+3/2"
    elif M == -1.5:
        m_str = r"$-$3/2"
    elif M == 0.5:
        m_str = "+½"
    else:
        m_str = r"$-$½"
    return f"{blocco}, $M$={m_str}"


ETICHETTE_ASSE = [_etichetta_stato(blocco, M) for blocco, M in ORDINE]


def _matrice_kambe(mode):
    """H nella base di Kambe (ordine ORDINE), per l'opzione DM data."""
    states = kambe_states()
    V = np.array([states[key] for key in ORDINE]).T
    H = trimer_hamiltonian_dm(J, JP, B_WORK, mode, D_WORK).to_matrix()
    return V.conj().T @ H @ V


def _verifica_commutatore_P12():
    """Cross-check indipendente: max|[P12,H_DM]| noto (0 per A, 0.42 per B)."""
    def P12_matrix():
        P = np.zeros((8, 8))
        for b1 in (0, 1):
            for b2 in (0, 1):
                for b3 in (0, 1):
                    idx_in = 4 * b1 + 2 * b2 + b3
                    idx_out = 4 * b2 + 2 * b1 + b3
                    P[idx_out, idx_in] = 1
        return P

    from trimer_ring_exact import dm_term
    P12 = P12_matrix()
    H_A = (dm_term(2, 3, D_WORK) + dm_term(3, 1, -D_WORK)).to_matrix()
    H_B = (dm_term(1, 2, D_WORK * J) + dm_term(2, 3, D_WORK * JP)
           + dm_term(3, 1, D_WORK * JP)).to_matrix()
    comm_A = np.max(np.abs(P12 @ H_A @ P12.T - H_A))
    comm_B = np.max(np.abs(P12 @ H_B @ P12.T - H_B))
    print(f"[verifica] max|[P12,H_DM]|: Opzione A = {comm_A:.3e} (atteso ~0), "
          f"Opzione B = {comm_B:.3f} (atteso ~0.42)")
    assert comm_A < 1e-8, "Opzione A: commutatore con P12 non nullo, controllare"
    assert abs(comm_B - 0.42) < 1e-2, "Opzione B: commutatore diverso da 0.42, controllare"


def _verifica_struttura_a_blocchi(Hk_A, Hk_B):
    """La figura deve mostrare 2x2(C) isolato + 6x6(A+B) pieno per A,
    e 8x8 pieno per B. Si ferma con errore se non e' cosi', invece di
    disegnare comunque la figura."""
    mask_A = np.abs(Hk_A) > SOGLIA
    mask_B = np.abs(Hk_B) > SOGLIA

    C_vs_resto_A = mask_A[:2, 2:]
    assert not C_vs_resto_A.any(), (
        "Opzione A: il blocco C non risulta isolato dal resto -- la figura "
        "non mostrerebbe la struttura attesa, controllare prima di procedere."
    )
    C_vs_resto_B = mask_B[:2, 2:]
    assert C_vs_resto_B.any(), (
        "Opzione B: il blocco C risulta isolato dal resto (atteso: mescolato) "
        "-- la figura non mostrerebbe la struttura attesa, controllare."
    )
    print("[verifica] struttura a blocchi: Opzione A ha blocco C isolato "
          f"(2x2) + resto pieno (6x6); Opzione B ha C mescolato con il resto "
          f"({C_vs_resto_B.sum()} elementi non nulli fuori dal blocco C).")


def _pannello(ax, Hk, titolo, con_ylabel):
    mask = (np.abs(Hk) > SOGLIA).astype(int)
    cmap = ListedColormap(["white", C_VIOLA])
    ax.imshow(mask, cmap=cmap, vmin=0, vmax=1)

    ax.set_xticks(range(8))
    ax.set_yticks(range(8))
    ax.set_xticklabels(ETICHETTE_ASSE, fontsize=10, rotation=90)
    ax.set_yticklabels(ETICHETTE_ASSE, fontsize=10)

    # separatore nero dopo la 2a riga/colonna: delimita il blocco C dal resto
    ax.axhline(1.5, color="black", linewidth=1.6)
    ax.axvline(1.5, color="black", linewidth=1.6)

    ax.set_xlabel("stato (blocco, numero quantico $M$)", fontsize=11)
    if con_ylabel:
        ax.set_ylabel("stato (blocco, numero quantico $M$)", fontsize=11)

    ax.set_title(titolo, fontsize=13)


if __name__ == "__main__":
    _verifica_commutatore_P12()

    Hk_A = _matrice_kambe("A")
    Hk_B = _matrice_kambe("B")
    _verifica_struttura_a_blocchi(Hk_A, Hk_B)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11.6, 6.4))
    _pannello(ax1, Hk_A, "Opzione A (simmetrica)", con_ylabel=True)
    _pannello(ax2, Hk_B, "Opzione B (adottata)", con_ylabel=False)

    fig.suptitle(
        "Struttura a blocchi di $H$ nella base di Kambe: ogni riquadro "
        "etichettato\ncon (blocco C/A/B, numero quantico $M$ = proiezione "
        "dello spin totale)",
        fontsize=13.5,
    )

    fig.savefig("figure/fig_blocchi_dm_trimero_anello.pdf", bbox_inches="tight")
    fig.savefig("figure/fig_blocchi_dm_trimero_anello.png", bbox_inches="tight", dpi=200)
    plt.close(fig)
    print("[ok] figure/fig_blocchi_dm_trimero_anello.pdf")
