"""
Genera due figure sullo spostamento dell'incrocio C<->A sotto l'Opzione A
del termine DM (simmetrica, non apre il gap ma sposta comunque il punto
di incrocio per via del mescolamento interno al settore S12=1):

  fig_spostamento_incrocio_trimero_anello.pdf
      tre rami di energia vicino all'incrocio: C(M=-1/2) esatto (nero),
      lo stato piu' basso del blocco 6x6 misto A+B sotto Opzione A
      (arancio), e lo stesso stato A(M=-3/2) calcolato SENZA
      mescolamento, cioe' la formula D=0 pura (blu tratteggiato).

  fig_matrice_kambe_opzioneA_trimero_anello.pdf
      la stessa matrice H (Opzione A, b/J=2.372, D/J=0.15) gia' usata
      per fig_blocchi_dm_trimero_anello.pdf, qui con i valori numerici
      scritti in ogni cella non nulla, e tre riquadri colorati che
      identificano gli elementi responsabili dei due rami della prima
      figura (stessa codifica colore: nero, blu tratteggiato, arancio).

Punto di lavoro: J=1, J'=0.4, D/J=0.15 (Opzione A). Il gap fra i due
rami e' verificato indipendentemente contro dm_min_gap('A', D) --
trovato ~2.3e-8 a b/J=2.372, coerente con quanto gia' riportato nel
testo per l'Opzione A.
"""
import numpy as np
from matplotlib.patches import Rectangle
from trimer_ring_exact import trimer_hamiltonian_dm, kambe_states, dm_min_gap
from stile import plt, salva, C_NERO, C_BLU, C_ARANC

J, JP, D_WORK = 1.0, 0.4, 0.15

ORDINE = [("C", 0.5), ("C", -0.5),
          ("A", 1.5), ("A", 0.5), ("A", -0.5), ("A", -1.5),
          ("B", 0.5), ("B", -0.5)]


def _etichetta_stato(blocco, M):
    if M == 1.5:
        m_str = "+3/2"
    elif M == -1.5:
        m_str = r"$-$3/2"
    elif M == 0.5:
        m_str = "+½"
    else:
        m_str = r"$-$½"
    return f"{blocco}, $M$={m_str}"


ETICHETTE_ASSE = [_etichetta_stato(blocco, M) for blocco, M in ORDINE]
V_KAMBE = np.array([states for states in kambe_states().values()])  # non usato direttamente
_STATI = kambe_states()
V = np.array([_STATI[key] for key in ORDINE]).T  # colonne = stati di Kambe, ordine fissato


def _matrice_kambe(b, mode=None, D=0.0):
    H = trimer_hamiltonian_dm(J, JP, b, mode, D).to_matrix()
    return np.real(V.conj().T @ H @ V)


def E_C_basso(b):
    """Ramo piu' basso del blocco C: formula D=0 esatta (C isolato anche
    sotto l'Opzione A, verificato: nessun elemento fuori diagonale lo
    tocca)."""
    return -3 * J - b


def E_A_puro(b):
    """A(M=-3/2) SENZA mescolamento: formula D=0 pura per quello stato."""
    return (J + 2 * JP) - 3 * b


def E_6x6_basso(b, D):
    """Stato piu' basso del blocco 6x6 misto (A+B), Opzione A, DM D."""
    Hk = _matrice_kambe(b, mode="A", D=D)
    return np.linalg.eigvalsh(Hk[2:, 2:])[0]


# ----------------------------------------------------------------------
# Verifiche indipendenti prima di disegnare
# ----------------------------------------------------------------------

def _verifica():
    b_grid = np.linspace(2.2, 2.55, 5)
    for b in b_grid:
        Hk0 = _matrice_kambe(b)  # D=0, nessun DM
        assert np.isclose(Hk0[1, 1], E_C_basso(b), atol=1e-10), \
            "il ramo C(M=-1/2) a D=0 non coincide con la formula analitica"
        assert np.isclose(Hk0[5, 5], E_A_puro(b), atol=1e-10), \
            "A(M=-3/2) a D=0 non coincide con la formula analitica"

    Hk_A = _matrice_kambe(2.372, mode="A", D=D_WORK)
    assert np.isclose(Hk_A[1, 1], E_C_basso(2.372), atol=1e-10), \
        "C(M=-1/2) sotto Opzione A non coincide piu' con la formula D=0: " \
        "il blocco C non e' isolato come atteso, controllare"
    coupling = Hk_A[5, 7]
    assert abs(abs(coupling) - 0.367) < 0.01, \
        f"accoppiamento A(-3/2)-B(-1/2) inatteso: {coupling}, attesi ~0.367"

    gap, b_at_gap = dm_min_gap(J, JP, "A", D_WORK)
    print(f"[verifica] dm_min_gap Opzione A: gap={gap:.3e} a b/J={b_at_gap:.4f} "
          f"(atteso: gap~0, b/J~2.372)")
    assert gap < 1e-6 and abs(b_at_gap - 2.372) < 0.01

    w6 = np.linalg.eigvalsh(Hk_A[2:, 2:])
    v6 = np.linalg.eigh(Hk_A[2:, 2:])[1][:, 0]
    peso_A32 = v6[3] ** 2      # indice 3 nel blocco 6x6 = A(M=-3/2)
    peso_Bm12 = v6[5] ** 2     # indice 5 nel blocco 6x6 = B(M=-1/2)
    print(f"[verifica] stato piu' basso del blocco 6x6 a b/J=2.372: "
          f"{peso_A32*100:.1f}% A(-3/2), {peso_Bm12*100:.1f}% B(-1/2)")
    assert abs(peso_A32 - 0.977) < 0.01 and abs(peso_Bm12 - 0.023) < 0.01

    print(f"[verifica] accoppiamento A(-3/2)-B(-1/2) = {coupling:.6f} "
          f"(atteso ~-0.367, corretto rispetto al valore errato "
          f"precedentemente riportato nel testo, 1.13)")


# ----------------------------------------------------------------------
# Figura 1: spostamento dell'incrocio
# ----------------------------------------------------------------------

def figura_1():
    b_vals = np.linspace(2.2, 2.55, 400)
    e_C = np.array([E_C_basso(b) for b in b_vals])
    e_A_puro = np.array([E_A_puro(b) for b in b_vals])
    e_6x6 = np.array([E_6x6_basso(b, D_WORK) for b in b_vals])

    b_old = 2.4                      # incrocio D=0 (C vs A puro), esatto
    b_new = 2.371819635183148        # incrocio Opzione A (C vs 6x6 misto)

    fig, ax = plt.subplots(figsize=(7.2, 5.0))
    ax.plot(b_vals, e_C, color=C_NERO, lw=2.4, label="C ($M{=}{-}1/2$), esatto")
    ax.plot(b_vals, e_6x6, color=C_ARANC, lw=2.4,
            label="stato più basso del blocco $6\\times6$ (Opzione A)")
    ax.plot(b_vals, e_A_puro, color=C_BLU, lw=2.0, ls="--",
            label="A ($M{=}{-}3/2$), senza mescolamento (D=0)")

    ax.axvline(b_old, color=C_BLU, ls=":", lw=1.3)
    ax.axvline(b_new, color=C_ARANC, ls=":", lw=1.3)

    ax.annotate("nuovo incrocio\n$b/J\\approx2.372$\n(C $\\leftrightarrow$ blocco $6\\times6$)",
                xy=(b_new, E_C_basso(b_new)), xytext=(2.24, -6.05),
                ha="center", fontsize=8.8, color="0.2",
                arrowprops=dict(arrowstyle="->", color=C_ARANC, lw=1.1))
    ax.annotate("vecchio incrocio\n$b/J=2.400$\n(C $\\leftrightarrow$ A puro)",
                xy=(b_old, E_C_basso(b_old)), xytext=(2.50, -6.05),
                ha="center", fontsize=8.8, color="0.2",
                arrowprops=dict(arrowstyle="->", color=C_BLU, lw=1.1))

    ax.set_ylim(-6.35, -4.55)

    ax.set_xlabel("$b/J$")
    ax.set_ylabel("$E/J$")
    ax.set_title("Spostamento del punto di incrocio sotto l'Opzione A")
    ax.legend(loc="upper right", fontsize=9.5)

    salva(fig, "fig_spostamento_incrocio_trimero_anello")


# ----------------------------------------------------------------------
# Figura 2: matrice di Kambe annotata (Opzione A)
# ----------------------------------------------------------------------

def figura_2():
    Hk = _matrice_kambe(2.372, mode="A", D=D_WORK)

    fig, ax = plt.subplots(figsize=(7.4, 7.0))
    ax.imshow(np.zeros_like(Hk), cmap="Greys", vmin=0, vmax=1)  # sfondo bianco

    for r in range(8):
        for c in range(8):
            val = Hk[r, c]
            if abs(val) > 1e-8:
                ax.text(c, r, f"{val:.3f}", ha="center", va="center", fontsize=9.5)

    ax.set_xticks(range(8)); ax.set_yticks(range(8))
    ax.set_xticklabels(ETICHETTE_ASSE, fontsize=9.5, rotation=90)
    ax.set_yticklabels(ETICHETTE_ASSE, fontsize=9.5)
    for k in range(9):
        ax.axhline(k - 0.5, color="0.85", lw=0.6, zorder=0)
        ax.axvline(k - 0.5, color="0.85", lw=0.6, zorder=0)

    # separatore C / (A+B)
    ax.axhline(1.5, color="black", linewidth=1.8)
    ax.axvline(1.5, color="black", linewidth=1.8)

    # riquadro nero: C(M=-1/2), ramo comune ai due incroci
    ax.add_patch(Rectangle((1 - 0.46, 1 - 0.46), 0.92, 0.92, fill=False,
                            edgecolor=C_NERO, linewidth=2.4))
    # riquadro blu tratteggiato: A(M=-3/2), vecchio incrocio (D=0 puro)
    ax.add_patch(Rectangle((5 - 0.46, 5 - 0.46), 0.92, 0.92, fill=False,
                            edgecolor=C_BLU, linewidth=2.4, linestyle="--"))
    # riquadro arancio: accoppiamento A(-3/2)-B(-1/2), nuovo incrocio
    ax.add_patch(Rectangle((7 - 0.46, 5 - 0.46), 0.92, 0.92, fill=False,
                            edgecolor=C_ARANC, linewidth=2.4))
    ax.add_patch(Rectangle((5 - 0.46, 7 - 0.46), 0.92, 0.92, fill=False,
                            edgecolor=C_ARANC, linewidth=2.4))

    ax.set_title("Matrice di Kambe, Opzione A ($b/J{=}2.372$, $D/J{=}0.15$)")
    salva(fig, "fig_matrice_kambe_opzioneA_trimero_anello")


if __name__ == "__main__":
    _verifica()
    figura_1()
    figura_2()
