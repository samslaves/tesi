"""
Genera i diagrammi circuitali a livello di gate dei due blocchi a due
qubit usati negli ansatz (RBS e W), non le scatole nere compatte gia'
usate altrove (circ_rbs2q_anello.pdf, circ_w2q_anello.pdf).

Sequenze verificate contro il codice del progetto:
  - RBS: ansatz_catena.py::rbs_block         -> H,H; CZ; Ry(phi),Ry(-phi); CZ; H,H
  - W:   vqe_w2q6_trimero_anello.py::w_block -> CX; Ry(theta); CX

Uno stesso file produce le due figure separate (stesso stile del resto
del pacchetto: default Qiskit mpl drawer, gia' usato per le altre figure
di circuito del progetto), da affiancare in LaTeX con un minipage, come
gia' fatto per circ_rbs2q_anello.pdf / circ_w2q_anello.pdf.
"""
from qiskit import QuantumCircuit
from qiskit.circuit import Parameter


def _salva(fig, nome):
    fig.savefig(f"figure/{nome}.pdf", bbox_inches="tight")
    fig.savefig(f"figure/{nome}.png", bbox_inches="tight", dpi=200)
    print(f"[ok] figure/{nome}.pdf")


def circuito_rbs_espanso():
    phi = Parameter("φ")
    qc = QuantumCircuit(2)
    qc.h(0); qc.h(1)
    qc.cz(0, 1)
    qc.ry(phi, 0); qc.ry(-phi, 1)
    qc.cz(0, 1)
    qc.h(0); qc.h(1)

    assert qc.count_ops().get("h", 0) == 4
    assert qc.count_ops().get("cz", 0) == 2
    assert qc.count_ops().get("ry", 0) == 2

    fig = qc.draw("mpl")
    fig.axes[0].set_title(r"RBS($\varphi$)  —  2 CZ + 4 H", fontsize=13, pad=16)
    _salva(fig, "fig_circuito_rbs_espanso_trimero_anello")


def circuito_w_espanso():
    theta = Parameter("θ")
    qc = QuantumCircuit(2)
    qc.cx(0, 1)
    qc.ry(theta, 0)
    qc.cx(0, 1)

    assert qc.count_ops().get("cx", 0) == 2
    assert qc.count_ops().get("ry", 0) == 1

    fig = qc.draw("mpl")
    fig.axes[0].set_title(r"W($\theta$)  —  2 CX", fontsize=13, pad=16)
    _salva(fig, "fig_circuito_w_espanso_trimero_anello")


if __name__ == "__main__":
    circuito_rbs_espanso()
    circuito_w_espanso()
